package com.example.weatherapp.Common;

import android.location.Location;

public class Common {

    public static final String API_KEY = "e39c2965443a872db87c95e5975e2703";
    public static Location current_location = null;
}
